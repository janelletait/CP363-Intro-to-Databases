'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-28'
----------------------------------------------
'''
from Connect import Connect
from functions import get_member_publications


conn = Connect("dcris.txt")
cursor = conn.cursor
    
    
rows = get_member_publications(cursor)
    
for row in rows:
    print(row)
        
conn.close()