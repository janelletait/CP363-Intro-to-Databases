'''
----------------------------------------------
assignment 2
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-28'
----------------------------------------------
'''

def get_member_publications(cursor, title=None, pub_type_id=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = get_member_publications(cursor)
    Use: rows = get_member_publications(cursor, title=v1)
    Use: rows = get_member_publications(cursor, pub_type_id=v2)
    Use: rows = get_member_publications(cursor, title=v1, pub_type_id=v2)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        title - a partial title (str)
        pub_type_id - a publication type (str)
    Returns:
        rows - (list of member's last name, a member's first
            name, the title of a publication, and the full publication
            type (i.e. 'article' rather than 'a') data)
            if title and/or pub_type_id are not None:
                rows containing title and/or pub_type_id
            else:
                all member and publication rows
            Sorted by last name, first name, title
    -------------------------------------------------------
    """
    
    if(title == None and pub_type_id == None):
        sql= """SELECT M.last_name, M.first_name, P.p_title, PT.pt_desc 
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id 
                JOIN pub_type AS PT ON PT.pub_type_id = P.pub_type_id 
                ORDER BY M.last_name, M.first_name, P.p_title"""
              
        cursor.execute(sql)
        
        
    elif(title != None and pub_type_id == None):  
        sql= """SELECT M.last_name, M.first_name, P.p_title, PT.pt_desc 
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id 
                JOIN pub_type AS PT ON PT.pub_type_id = P.pub_type_id 
                WHERE P.p_title LIKE %s
                ORDER BY M.last_name, M.first_name, P.p_title"""
        
        params = ['%' + title + '%']
        cursor.execute(sql, params)
        
        
    elif(title == None and pub_type_id != None):
        
        sql= """SELECT M.last_name, M.first_name, P.p_title, PT.pt_desc 
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id 
                JOIN pub_type AS PT ON PT.pub_type_id = P.pub_type_id 
                WHERE P.pub_type_id LIKE %s
                ORDER BY M.last_name, M.first_name, P.p_title"""
        
        params = [pub_type_id]
        cursor.execute(sql, params)
        
    else:
        
        sql= """SELECT M.last_name, M.first_name, P.p_title, PT.pt_desc 
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id 
                JOIN pub_type AS PT ON PT.pub_type_id = P.pub_type_id 
                WHERE P.p_title LIKE %s AND P.pub_type_id LIKE %s
                ORDER BY M.last_name, M.first_name, P.p_title"""
        
        params = ['%'+title+'%', pub_type_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows


def get_publication_counts(cursor, member_id=None, pub_type_id=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = get_publication_counts(cursor)
    Use: rows = get_publication_counts(cursor, member_id=v1)
    Use: rows = get_publication_counts(cursor, pub_type_id=v2)
    Use: rows = get_publication_counts(cursor, member_id=v1, pub_type_id=v2)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        member_id - a member ID number (int)
        pub_type_id - a publication type (str)
    Returns:
        rows - (list of member's last name, a member's first
            name, and the number of publications of type
            pub_type_id data)
            if member_id or pub_type_id is not None:
                rows containing member_id and/or pub_type_id
            else:
                all member names and publication counts
            Sorted by last name, first name
    -------------------------------------------------------
    """
    
    if(member_id == None and pub_type_id == None):
        sql = """SELECT M.last_name, M.first_name, COUNT(P.pub_type_id)
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""
                
        cursor.execute(sql)
        
        
    elif(member_id != None and pub_type_id == None):      
        
        sql = """SELECT M.last_name, M.first_name, COUNT(P.pub_type_id)
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id
                WHERE M.member_id LIKE %s
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""
        
        params = [member_id]
        cursor.execute(sql, params)
        
        
    elif(member_id == None and pub_type_id != None):
        
        sql = """SELECT M.last_name, M.first_name, COUNT(P.pub_type_id)
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id
                WHERE P.pub_type_id LIKE %s
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""
        
        params = [pub_type_id]
        cursor.execute(sql, params)
        
    else:
        
        sql = """SELECT M.last_name, M.first_name, COUNT(P.pub_type_id)
                FROM member AS M
                JOIN pub AS P ON P.member_id = M.member_id
                WHERE M.member_id LIKE %s AND P.pub_type_id LIKE %s
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""
        
        params = [member_id, pub_type_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    

def get_keyword_counts(cursor, member_id=None):
    """
    -------------------------------------------------------
    Queries the member and keyword tables.
    Use: rows = get_keyword_counts(cursor)
    Use: rows = get_keyword_counts(cursor, member_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        member_id - a member ID number (int)
    Returns:
        rows - (list of member's last name, a member's first
            name, and the number of expertises (i.e. keywords)
            they hold data)
            if member_id is not None:
                rows containing member_id
            else:
                all member and expertise rows
            Sorted by last name, first name
    -------------------------------------------------------
    """
    
    if(member_id == None):
        sql = """SELECT M.last_name, M.first_name, COUNT(MK.keyword_id)
                FROM member AS M
                JOIN member_keyword AS MK ON MK.member_id = M.member_id
                JOIN keyword AS K ON K.keyword_id = MK.keyword_id
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""

        cursor.execute(sql)
        
    else:
        
        sql = """SELECT M.last_name, M.first_name, COUNT(MK.keyword_id)
                FROM member AS M
                JOIN member_keyword AS MK ON MK.member_id = M.member_id
                JOIN keyword AS K ON K.keyword_id = MK.keyword_id
                WHERE M.member_id LIKE %s
                GROUP BY M.last_name, M.first_name
                ORDER BY M.last_name, M.first_name"""

        params = [member_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    

    
def get_all_expertises(cursor, member_id=None):
    """
    -------------------------------------------------------
    Queries the member, keyword, and supp_key tables
    Use: rows = get_all_expertises(cursor)
    Use: rows = get_all_expertises(cursor, member_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        member_id - a member ID number (int)
    Returns:
        rows - (list of member's last name, a member's first
            name, a keyword description, and a supplementary
            keyword description data)
            if member_id is not None:
                rows containing member_id
            else:
                all member and expertise rows
            Sorted by last name, first name, keyword description, supplementary
                keyword description
    -------------------------------------------------------
    """
    if(member_id == None):
        sql = '''SELECT M.last_name, M.first_name, K.k_desc, SK.sk_desc
                FROM member AS M
                JOIN member_keyword AS MK ON MK.member_id = M.member_id
                JOIN keyword AS K ON K.keyword_id = MK.keyword_id
                JOIN supp_key AS SK ON SK.keyword_id = MK.keyword_id
                ORDER BY M.last_name, M.first_name, K.k_desc, SK.sk_desc'''

        cursor.execute(sql)
        
    else:
        
        sql = '''SELECT M.last_name, M.first_name, K.k_desc, SK.sk_desc
                FROM member AS M
                JOIN member_keyword AS MK ON MK.member_id = M.member_id
                JOIN keyword AS K ON K.keyword_id = MK.keyword_id
                JOIN supp_key AS SK ON SK.keyword_id = MK.keyword_id
                WHERE M.member_id LIKE %s
                ORDER BY M.last_name, M.first_name, K.k_desc, SK.sk_desc'''
        
        params = [member_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    
    













