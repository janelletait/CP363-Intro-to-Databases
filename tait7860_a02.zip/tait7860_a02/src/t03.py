'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-28'
----------------------------------------------
'''

from Connect import Connect
from functions import get_keyword_counts


conn = Connect("dcris.txt")
cursor = conn.cursor
    
    
rows = get_keyword_counts(cursor, 42)
    
for row in rows:
    print(row)
        
conn.close()