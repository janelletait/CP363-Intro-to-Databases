'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-03-03'
----------------------------------------------
'''

def get_all_pub_counts(cursor, member_id=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = pub_counts(cursor)
    Use: rows = pub_counts(cursor, member_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        member_id - a member ID number (int)
    Returns:
        rows - (list of member's last name, a member's first
            name, and the numbers of publications of each type data.
            Name these three fields "articles", "papers", and "books")
            if member_id is not None:
                rows containing member_id
            else:
                all member and publication rows
            Sorted by last name, first name
    -------------------------------------------------------
    """
    
    if(member_id == None):
        
        sql ="""SELECT M.last_name, M.first_name,
        
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'a' AND P.member_id = M.member_id) AS articles,
                
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'p' AND P.member_id = M.member_id) AS papers,
                
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'b' AND P.member_id = M.member_id) AS books
                
                FROM member AS M
                ORDER BY M.last_name, M.first_name"""
                      
        cursor.execute(sql)
        
    else:
        
        sql ="""SELECT M.last_name, M.first_name,
        
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'a' AND P.member_id = M.member_id) AS articles,
                
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'p' AND P.member_id = M.member_id) AS papers,
                
                (SELECT COUNT(P.pub_type_id)
                FROM pub AS P
                WHERE P.pub_type_id = 'b' AND P.member_id = M.member_id) AS books
                
                FROM member AS M
                WHERE M.member_id LIKE %s
                ORDER BY M.last_name, M.first_name"""
                        
        params = [member_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows



def get_expertise_counts(cursor, member_id=None):
    """
    -------------------------------------------------------
    Use: rows = get_expertise_counts(cursor)
    Use: rows = get_expertise_counts(cursor, member_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        member_id - a member ID number (int)
    Returns:
        rows - (list of member's last name, a member's first
            name, and the number of keywords and supplementary keywords
            for the member data. Name these fields "keywords" and "supp_keys")
            if member_id is not None:
                rows containing member_id
            else:
                all member, keyword, and supplementary keyword rows
            Sorted by last name, first name
   -------------------------------------------------------
    """
         
    
    if(member_id == None):
        
        sql ="""SELECT M.last_name, M.first_name,
        
                (SELECT COUNT(DISTINCT MK.keyword_id)
                FROM member_keyword AS MK
                WHERE MK.member_id = M.member_id) AS keywords,
                
                (SELECT COUNT(DISTINCT MSK.supp_key_id)
                FROM member_supp_key AS MSK
                WHERE MSK.member_id = M.member_id) AS supp_keys
                
                FROM member AS M
                ORDER BY M.last_name, M.first_name"""              
        
        cursor.execute(sql)
        
    else:
        
        sql ="""SELECT M.last_name, M.first_name,
        
                (SELECT COUNT(DISTINCT MK.keyword_id)
                FROM member_keyword AS MK
                WHERE MK.member_id = M.member_id) AS keywords,
                
                (SELECT COUNT(DISTINCT MSK.supp_key_id)
                FROM member_supp_key AS MSK
                WHERE MSK.member_id = M.member_id) AS supp_keys
                
                FROM member AS M
                WHERE M.member_id LIKE %s
                ORDER BY M.last_name, M.first_name"""    
                
        params = [member_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    
    
def get_keyword_counts(cursor, keyword_id=None):
    """
    -------------------------------------------------------
    Use: rows = get_keyword_counts(cursor)
    Use: rows = get_keyword_counts(cursor, keyword_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        keyword_id - a keyword ID number (int)
    Returns:
        rows - (list of a keyword's description and the number of
            supplementary keywords that belong to it data. Name the
            second field "supp_key_count".)
            if keyword_id is not None:
                rows containing keyword_id
            else:
                all keyword and supplementary keyword rows
            Sorted by keyword description
    -------------------------------------------------------
    """ 
    
    if(keyword_id == None):
        
        sql ="""SELECT K.k_desc,
        
                (SELECT COUNT(DISTINCT SK.supp_key_id)
                FROM supp_key AS SK
                WHERE SK.keyword_id = K.keyword_id) AS supp_key_count
                
                FROM keyword AS K
                ORDER BY K.k_desc"""              
        
        cursor.execute(sql)
        
    else:
        
        sql ="""SELECT K.k_desc,
        
                (SELECT COUNT(DISTINCT SK.supp_key_id)
                FROM supp_key AS SK
                WHERE SK.keyword_id = K.keyword_id) AS supp_key_count
                
                FROM keyword AS K
                WHERE K.keyword_id LIKE %s
                ORDER BY K.k_desc"""    
                
        params = [keyword_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    
    
def get_keyword_member_counts(cursor, keyword_id=None):
    """
    -------------------------------------------------------
    Use: rows = get_keyword_member_counts(cursor)
    Use: rows = get_keyword_member_counts(cursor, keyword_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        keyword_id - a keyword ID number (int)
    Returns:
        rows - (list of a keyword description and the number of members
            that have it data. Name the second field "member_count".)
            if keyword_id is not None:
                rows containing keyword_id
            else:
                all member and keyword rows
            Sorted by keyword description
    -------------------------------------------------------
    """
    
    if(keyword_id == None):
        
        sql ="""SELECT K.k_desc,
        
                (SELECT COUNT(DISTINCT MK.member_id)
                FROM member_keyword AS MK
                WHERE MK.keyword_id = K.keyword_id) AS member_count
                
                FROM keyword AS K
                ORDER BY K.k_desc"""              
        
        cursor.execute(sql)
        
    else:
        
        sql ="""SELECT K.k_desc,
        
                (SELECT COUNT(DISTINCT MK.member_id)
                FROM member_keyword AS MK
                WHERE MK.keyword_id = K.keyword_id) AS member_count
                
                FROM keyword AS K
                WHERE K.keyword_id LIKE %s
                ORDER BY K.k_desc"""  
                
        params = [keyword_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    

def get_supp_key_member_counts(cursor, supp_key_id=None):
    """
    -------------------------------------------------------
    Use: rows = get_supp_key_member_counts(cursor)
    Use: rows = get_supp_key_member_counts(cursor, supp_key_id=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        supp_key_id - a supp_key ID number (int)
    Returns:
        rows - (list of a keyword's description, a supplementary
            keyword description, and the number of members that have that
            supplementary expertise data. Name the last field "member_count".)
            if supp_key_id is not None:
                rows containing supp_key_id
            else:
                all member, keyword, and supplementary keyword rows
            Sorted by keyword description, supplementary keyword description
    -------------------------------------------------------
    """    
    
    if(supp_key_id == None):                   
        
        sql ="""SELECT K.k_desc, SK.sk_desc,
        
                (SELECT COUNT(DISTINCT MSK.member_id)
                FROM member_supp_key AS MSK
                WHERE MSK.supp_key_id = SK.supp_key_id) AS member_count
                
                FROM keyword AS K
                JOIN supp_key AS SK ON SK.keyword_id = K.keyword_id
                ORDER BY K.k_desc, SK.sk_desc"""              
        
        cursor.execute(sql)
        
    else:
        
        sql ="""SELECT K.k_desc, SK.sk_desc,
        
                (SELECT COUNT(DISTINCT MSK.member_id)
                FROM member_supp_key AS MSK
                WHERE MSK.supp_key_id = SK.supp_key_id) AS member_count
                
                FROM keyword AS K
                JOIN supp_key AS SK ON SK.keyword_id = K.keyword_id
                WHERE SK.supp_key_id LIKE %s
                ORDER BY K.k_desc, SK.sk_desc"""    
                
        params = [supp_key_id]
        cursor.execute(sql, params)
        
    rows = cursor.fetchall()
    
    return rows
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
                
            
        