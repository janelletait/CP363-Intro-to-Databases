'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-03-03'
----------------------------------------------
'''

from Connect import Connect
from functions import get_keyword_counts


conn = Connect("dcris.txt")
cursor = conn.cursor
    
    
rows = get_keyword_counts(cursor, keyword_id = 7)
    
for row in rows:
    print(row)
        
conn.close()