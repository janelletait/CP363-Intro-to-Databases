'''
----------------------------------------------
assignment 1
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-12'
----------------------------------------------
'''
from Connect import Connect
from functions import get_member_expertises


conn = Connect("dcris.txt")
cursor = conn.cursor
    
#member_id = 107
#pub_type_id = 'b'
    
rows = get_member_expertises(cursor)
    
for row in rows:
    print(row)
        
conn.close()