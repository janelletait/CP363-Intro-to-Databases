'''
----------------------------------------------
assignment 1
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-12'
----------------------------------------------
'''
from Connect import Connect
from functions import get_keywords


conn = Connect("dcris.txt")
cursor = conn.cursor
    
keyword_id = 7
    
rows = get_keywords(cursor)
    
for row in rows:
    print(row)
        
conn.close()