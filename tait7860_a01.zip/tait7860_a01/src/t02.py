'''
----------------------------------------------
assignment 1
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-02-12'
----------------------------------------------
'''
from Connect import Connect
from functions import get_publications


conn = Connect("dcris.txt")
cursor = conn.cursor
    
#member_id = 107
#pub_type_id = 'b'
    
rows = get_publications(cursor, 107, 'b')
    
for row in rows:
    print(row)
        
conn.close()