'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-03-19'
----------------------------------------------
'''

from Connect import Connect
from functions import get_foreign_key_info


conn = Connect("dcris.txt")
cursor = conn.cursor
    
constraint_schema = 'dcris'
    
rows = get_foreign_key_info(cursor, constraint_schema, table_name = 'pub', ref_table_name = 'member')
    
for row in rows:
    print(row)
        
conn.close()