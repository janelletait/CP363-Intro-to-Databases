'''
----------------------------------------------
[program description]
----------------------------------------------
Author: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
__updated__ = '2021-03-19'
----------------------------------------------
'''

from Connect import Connect
from functions import get_constraint_info


conn = Connect("dcris.txt")
cursor = conn.cursor
    
table_schema = 'dcris'
    
rows = get_constraint_info(cursor, table_schema, constraint_type = 'FOREIGN KEY')
    
for row in rows:
    print(row)
        
conn.close()